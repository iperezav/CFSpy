# CFSpy

A package that allows to simulate the output of a control system by means of the Chen-Fliess series.
